package gameserver;

class Player
{
 String name;
 String symbol;
 boolean chance;
}
